<!DOCTYPE html>
<html>
<head>
<title>University of Calgary Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="/css/index.css">

<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

<!-- CHANGE CSS SOURCE LATER-->
<link href="/testing/test.css" rel="stylesheet">

</head>
<body>
    <!-- $page is the type of page to set 'active' in the navbar (admin_nav.php)-->
    <?php $page = 'home'; include("admin_nav.php");?>

    <br>
    <h1> HOME PAGE </h1>
</body>
</html>
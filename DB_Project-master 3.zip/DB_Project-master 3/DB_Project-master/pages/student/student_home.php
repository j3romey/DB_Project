<!DOCTYPE html>
<html>
<head>
<title>University of Calgary Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">

<!-- CHANGE CSS SOURCE LATER-->
<link href="/testing/test.css" rel="stylesheet">

</head>
<body>
    <!-- $page is the type of page to set 'active' in the navbar (student_nav.php)-->
    <?php $page = 'home'; include("student_nav.php");?>

    <br>
    <h1> HOME PAGE </h1>
</body>
</html>
<?php
error_reporting(E_ALL); ini_set('display_errors', 'On');
$path = $_SERVER['DOCUMENT_ROOT'];
$path .= "/php/db_login.php";
include_once($path);

$department = $_POST['department'];
$number = $_POST['coursenumber'];


    $sql = "SELECT Cid from course WHERE Acronym = '$department' and Number = '$number'"; 
    $result = mysqli_query($conn, $sql);    
    $row = $result->fetch_assoc();
	$cid = $row['Cid'];
	echo $cid;

/*
    $sql = "SELECT Cid from course WHERE Acronym = '$department' and Number = '$number'"; 
    $result = mysqli_query($conn, $sql);    
    $row = $result->fetch_assoc();
	$cid = $row
*/

$sql = "DELETE FROM section 
        WHERE Cid = '$cid'";
        
$result = mysqli_query($conn, $sql);    

$sql = "DELETE FROM course 
        WHERE Cid = '$cid'";
        
//$sql = "DELETE FROM tutorial 
//        WHERE $'Cid' = 'sid'";
        
$result = mysqli_query($conn, $sql);

/*echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added the course')
    window.location.href='/pages/admin/admin_del.php';
    </SCRIPT>");*/
?>
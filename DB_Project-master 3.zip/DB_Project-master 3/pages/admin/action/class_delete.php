<?php

$path = $_SERVER['DOCUMENT_ROOT'];
$path .= "/php/db_login.php";
include_once($path);

$department = $_POST['department'];
$number = $_POST['coursenumber'];







$sql = "DELETE FROM course 
        WHERE Acronym = '$department' and Number = '$number'";
        
$result = mysqli_query($conn, $sql);

echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Added the course')
    window.location.href='/pages/admin/admin_del.php';
    </SCRIPT>");
?>